﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using StateManagementDemos.Models;
using StateManagementDemos.Services;
using Microsoft.Extensions.Caching.Redis;
using Microsoft.Extensions.Caching.Distributed;

namespace StateManagementDemos.Controllers
{
    public class HomeController : Controller
    {
        private DataService service;
        //private IMemoryCache memoryCache;
        IDistributedCache distributedCache;

        public HomeController(DataService svc,IDistributedCache distributedCache)
        {
            this.service = svc;
            this.distributedCache = distributedCache;
//            this.memoryCache = memoryCache;
        }
        public IActionResult Index()
        {
            //var userType = HttpContext.Items["usertype"].ToString();
            return View();
        }
        [HttpPost]
        public IActionResult Index(string firstName)
        {
            //Response.Cookies.Append("myname", firstName, new Microsoft.AspNetCore.Http.CookieOptions
            //{
            //    MaxAge=TimeSpan.FromMinutes(10),

            //});
            //HttpContext.Session.SetString("myname", firstName);
            // HttpContext.Session.CommitAsync();
            //TempData["myname"] = firstName;
            //TempData.Keep();
            //return RedirectToAction("About");
            //service.SetName(firstName);
            //MemoryCacheEntryOptions memoryCacheEntryOptions = new MemoryCacheEntryOptions()
            //{
            //    SlidingExpiration = TimeSpan.FromSeconds(180)
            //};
            //memoryCache.Set("myname", firstName, memoryCacheEntryOptions);
            DistributedCacheEntryOptions distributedCacheEntryOptions = new DistributedCacheEntryOptions()
            {
                SlidingExpiration = TimeSpan.FromMinutes(3)
            };
            distributedCache.SetString("myname", firstName, distributedCacheEntryOptions);
            return View();
        }

        public IActionResult About()
        {
            // ViewData["userName"] = Request.Cookies["myname"];
            // ViewData["userName"] = HttpContext.Session.GetString("myname");
            //var data = TempData.Peek("myname");
            //ViewData["userName"] = TempData["myname"];
            //ViewData["userName"] = service.GetName();
           // ViewData["userName"] = memoryCache.Get<string>("myname");
            //TempData.Peek("myname");
            //TempData.Keep();
            ViewData["Message"] = "Your application description page.";
            ViewData["userName"] = distributedCache.GetString("myname");
          //  Response.Cookies.Delete("myname");
            return View();
        }

        [ResponseCache(Duration =180,VaryByHeader ="*")]
        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
