﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dependencydemo.Models;
using dependencydemo.Services;

namespace dependencydemo.Controllers
{
    public class HomeController : Controller
    {
        private IDataService ds;

        public HomeController(IDataService service)
        {
            this.ds = service;
        }
        public IActionResult Index([FromServices]IDataService svc)
        {
            // ViewData["Message"] = svc.GetData();
            var service = HttpContext.RequestServices.GetService(typeof(IDataService)) as IDataService;
            ViewData["message"] = service.GetData();
            var x = ds.GetHashCode();
            var y = svc.GetHashCode();
            var z = service.GetHashCode();
            return View();
        }

        //public IActionResult Index()
        //{
        //    ViewData["Message"] = svc.GetData();
        //    return View();
        //}

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
