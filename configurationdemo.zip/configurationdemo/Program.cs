﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.WindowsServices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace configurationdemo
{
    public class Program
    {
        private static Dictionary<string, string> configDict = new Dictionary<string, string>()
        {
            {"DIctKey1","DictValue1" },
            {"DIctKey2","DictValue2" }
        };

        public static void Main(string[] args)
        {
            BuildWebHost(args).RunAsService();
        }

        //for 2.0 we can follow the below configuration
        //public static IWebHostBuilder BuildWebHost(string[] args)
        //{
        //    var exePath=Process.GetCurrentProcess().MainModule.FileName;
        //    var config = new ConfigurationBuilder()
        //                .SetBasePath(Directory.GetCurrentDirectory())
        //                .AddInMemoryCollection(configDict)
        //                .AddXmlFile("myconfig.xml")
        //                 .AddJsonFile("mysettings.json")
        //                 .AddJsonFile("appsettings.json")
        //                 .AddEnvironmentVariables()
        //                 .AddCommandLine(args)
        //                 .Build();
        //    return WebHost.CreateDefaultBuilder(args)
        //           .UseConfiguration(config)
        //           .UseStartup<Startup>();
        //}

        //after 2.1 onwards
        public static IWebHost BuildWebHost(string[] args)
        {
            var exePath = Process.GetCurrentProcess().MainModule.FileName;
            var contentPath = Path.GetDirectoryName(exePath);

            return WebHost.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((context, config) =>
                {
                    config.SetBasePath(Directory.GetCurrentDirectory())
                    .AddInMemoryCollection(configDict)
                    .AddXmlFile("myconfig.xml")
                    .AddJsonFile("mysettings.json")
                    .AddJsonFile("appsettings.json")
                    .AddEnvironmentVariables("CUSTOM_")
                    .AddCommandLine(args)
                    .Build();
                })
                .UseStartup<Startup>()
                .Build();
        }
            
    }
}
