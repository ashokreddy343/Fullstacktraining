﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MiddlewareDemos.Middleware
{
    public class DemoMiddleware
    {
        private RequestDelegate _next;
        public DemoMiddleware(RequestDelegate next)
        {
            this._next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            if (context.Request.Path == "/report")
            {
                if (context.Request.Protocol == "https")
                {
                    await context.Response.WriteAsync("Access using HTTPS<br/>");
                    await _next.Invoke(context);
                }
                else
                {
                    await context.Response.WriteAsync("can not be accessed using https.use HTTP<br/>");
                }
            }
            else
            {
                await _next.Invoke(context);
            }
        }
    }

    public static class MiddlewareExtensions
    {
        public static IApplicationBuilder UseDemoMiddleware(this IApplicationBuilder app)
        {
            return app.UseMiddleware<DemoMiddleware>();
        }
    }
}
