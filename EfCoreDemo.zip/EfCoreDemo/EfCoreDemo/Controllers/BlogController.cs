﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EfCoreDemo.Models;
using EfCoreDemo.Services;
using Microsoft.AspNetCore.Mvc;

namespace EfCoreDemo.Controllers
{
    [Route("blogs")]
    public class BlogController : Controller
    {
        private IBlogService blogService;

        public BlogController(IBlogService blogService)
        {
            this.blogService = blogService;
        }

        [HttpGet("",Name ="ListBlog")]
        public IActionResult Index([FromServices] IBlogService svc)
        {
            //var model = blogService.GetBlogs();
            var model = svc.GetBlogs();
            return View(model);
        }

        [HttpGet("new",Name ="AddBlog")]
        public IActionResult Create()
        {
            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost("new",Name ="AddBlog")]
        public async Task<IActionResult> Create(Blog model)
        {
            if (ModelState.IsValid)
            {
                await this.blogService.AddBlogAsync(model);
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("", "Invalid blog data");
            }
            return View();
        }
        [HttpGet("edit/{id:int?}",Name ="EditBlog")]
        public async Task<IActionResult> Edit([FromRoute]int? id,[FromServices]IBlogService svc)
        {
            if (id == null)
            {
                return NotFound();
            }
            var blog = await svc.GetBlogByIdAsync(id.Value);
            if (blog == null)
            {
                return NotFound();
            }
            else
            {
                return View(blog);
            }
        }

        [HttpPost("edit/{id:int?}", Name = "UpdateBlog")]
        public async Task<IActionResult> Edit([FromRoute]int? id,[Bind("Id,Title,Content,Email,AddedDate")] Blog model)
        {

            if (ModelState.IsValid)
            {
                await this.blogService.UpdateBlogAsync(id.Value, model);
                return RedirectToAction("Index");
            }
            else
            {
                return View(model);
            }
        }
    }
}