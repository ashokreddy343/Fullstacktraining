﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EfCoreDemo.Models;
using Microsoft.AspNetCore.Mvc;

namespace EfCoreDemo.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserInfo model)
        {
            //if (model.Email.EndsWith("gmail.com"))
            //{
            //    ModelState.AddModelError("Email", "Email cannot be from a public domain");
            //}
            if (ModelState.IsValid)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ModelState.AddModelError("", "User details validation failed");
                return View(model);
            }
        }

        
        public IActionResult VerifyUsername(string userName)
        {
            var userList = new[] { "abc", "abc1", "abc2", "abc3" };
            if (userList.Contains(userName))
            {
                //return Json(false);
                return Json("Username is already taken by somebody else");
            }
            else
            {
                //return Json(true);
                return Json("Username available");
            }
        }
    }
}