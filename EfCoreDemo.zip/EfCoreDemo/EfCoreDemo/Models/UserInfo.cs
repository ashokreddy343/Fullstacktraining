﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using EfCoreDemo.CustomAttributes;
using Microsoft.AspNetCore.Mvc;

namespace EfCoreDemo.Models
{
    public class UserInfo:IValidatableObject
    {
        [Required(ErrorMessage ="Username cannot be empty")]
        [MaxLength(40,ErrorMessage ="Username can contain maximum 40 characters")]
        [Remote("VerifyUsername","User",ErrorMessage ="Username not available")]
        public string UserName { get; set; }

        [DataType(DataType.Password)]
        [Required(ErrorMessage ="Password cannot be empty")]
        [StringLength(20,MinimumLength =8,ErrorMessage ="Password length must be between 8 and 20 characters")]
        public string Password { get; set; }

        [Compare(nameof(Password),ErrorMessage ="Password mismatch")]
        [DataType(DataType.Password)]
        [Required(ErrorMessage ="Confirm password cannot be empty")]
        [Display(Name ="Confirm Password")]
        public string ConfirmPassword { get; set; }

        [DataType(DataType.EmailAddress)]
        [MaxLength(70,ErrorMessage ="Email address is too long,max 70 characters")]
        [Required(ErrorMessage ="Email is required")]
       // [CompanyEmail]
        public string Email { get; set; }

        [Url(ErrorMessage ="Invalid url format")]
        [Required(ErrorMessage ="Company website address cannot be empty")]
        [Display(Name ="Company website")]

        public string CompanyUrl { get; set; }
        [Range(22,65,ErrorMessage ="Age must be between 22 and 65")]
        [Required(ErrorMessage ="Age cannot be empty")]
        public int Age { get; set; }

        [DataType(DataType.PhoneNumber,ErrorMessage ="Invalid phone number format")]
        public string Telephone { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Email.EndsWith("gmail.com"))
            {
                yield return new ValidationResult("Email cannot be from public domain",new[] { "Email"});
            }
            
        }
    }
}
