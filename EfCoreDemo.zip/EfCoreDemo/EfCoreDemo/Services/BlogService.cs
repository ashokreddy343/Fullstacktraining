﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EfCoreDemo.Models;

namespace EfCoreDemo.Services
{
    public class BlogService : IBlogService
    {
        public async Task<Blog> AddBlogAsync(Blog blog)
        {
            using (BlogContext db = new BlogContext())
            {
                blog.AddedDate = DateTime.Now;
                db.blogs.Add(blog);
                await db.SaveChangesAsync();
                return blog;
            }
             
        }

        public Blog GetBlogById(int id)
        {
            using (BlogContext db = new BlogContext())
            {
                var blog = db.blogs.SingleOrDefault(b => b.Id == id);
                return blog;
            }

        }

        public IEnumerable<Blog> GetBlogs()
        {
            using (BlogContext db = new BlogContext())
            {
                return db.blogs.ToList();
            }
        }

        public async Task<Blog> GetBlogByIdAsync(int id)
        {
            using (BlogContext db = new BlogContext())
            {
                var blog =  await db.blogs.FindAsync(id);
                return blog;
            }
        }

        public async Task<Blog> UpdateBlogAsync(int id, Blog blog)
        {
            using (BlogContext db = new BlogContext())
            {
                if (id != blog.Id)
                {
                    throw new Exception("Blog not found");
                }
                db.Update(blog);
                await db.SaveChangesAsync();
                return blog;
            }
        }
    }
}
