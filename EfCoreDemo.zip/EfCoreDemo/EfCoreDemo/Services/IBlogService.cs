﻿using EfCoreDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EfCoreDemo.Services
{
    public interface IBlogService
    {
        IEnumerable<Blog> GetBlogs();
        Blog GetBlogById(int id);

        Task<Blog> AddBlogAsync(Blog blog);
        Task<Blog> GetBlogByIdAsync(int id);
        Task<Blog> UpdateBlogAsync(int id,Blog blog);
    }
}
