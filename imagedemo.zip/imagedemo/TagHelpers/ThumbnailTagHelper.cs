﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace imagedemo.TagHelpers
{
    public class ThumbnailTagHelper:TagHelper
    {
        public string ImageUrl { get; set; }
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Attributes.SetAttribute("class", "col-md-4 thumbnail");
            output.TagMode = TagMode.StartTagAndEndTag;
            StringBuilder content = new StringBuilder("<figure>");
            content.AppendFormat("<img src='/images/{0}' style='max-height:200px; max-width:200px;'/>", ImageUrl);
            content.AppendFormat("<figcaption>{0}</figcaption>", ImageUrl);
            content.AppendFormat("</figure>");
            content.AppendFormat("<a href='/images/{0}' class='btn btn-primary'>View</a>", ImageUrl);
            output.Content.SetHtmlContent(content.ToString());
        }
    }
}

 
 