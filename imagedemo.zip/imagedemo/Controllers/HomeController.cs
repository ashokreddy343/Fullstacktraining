﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using imagedemo.Models;
using imagedemo.Services;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace imagedemo.Controllers
{
    public class HomeController : Controller
    {
        private IGalleryService gs;
        private IHostingEnvironment _hostingEnvironment;
        public HomeController(IGalleryService gservice, IHostingEnvironment hostingEnvironment)
        {
            this.gs = gservice;
            _hostingEnvironment = hostingEnvironment;
        }
        public IActionResult Index()
        {
            var result = gs.GetImages();
            ViewBag.Images = result;
            return View();
        }

        [HttpGet]
        public IActionResult AddImage()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddImage(IFormFile file)
        {
            string r = _hostingEnvironment.ContentRootPath;

           string filePath = $@"{Path.Combine(_hostingEnvironment.WebRootPath, "images")}\{Path.GetFileName(file.FileName)}";
            
           if (file.Length > 0)
            {
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
            }
            //imageData.filename = file.FileName;
           // gs.AddImage(imageData);

            return View();
        }



        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
