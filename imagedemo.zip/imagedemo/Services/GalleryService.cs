﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace imagedemo.Services
{
    public class GalleryService : IGalleryService
    {
        public Dictionary<string, string> GetImages()
        {
            Dictionary<string, string> obj = new Dictionary<string, string>();
            DirectoryInfo d = new DirectoryInfo(Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images"));
            FileInfo[] Files = d.GetFiles(); 
            foreach (FileInfo file in Files)
            {
                obj.Add(file.Name, file.FullName);
            }
            return obj;
        }


    }
}
