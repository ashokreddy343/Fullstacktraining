﻿using imagedemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace imagedemo.Services
{
    public interface IGalleryService
    {
        Dictionary<string, string> GetImages();
      //  Dictionary<string, string> AddImage(ImageData imagedata);
    }
}
