﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GalleryUseCase.Models;

namespace GalleryUseCase.Services
{
    public class GalleryService : IGalleryService
    {
        public ImageData AddImageData(ImageData imageData)
        {
            using(GalleryContext db=new GalleryContext())
            {
                db.images.Add(imageData);
                db.SaveChanges();
                return imageData;
            }
        }

        public IEnumerable<ImageData> GetImages()
        {
            using (GalleryContext db = new GalleryContext())
            {
                return db.images.ToList();
            }
        }
    }
}
