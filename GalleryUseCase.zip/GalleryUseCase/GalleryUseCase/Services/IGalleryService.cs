﻿using GalleryUseCase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GalleryUseCase.Services
{
    public interface IGalleryService
    {
        ImageData AddImageData(ImageData imageData);
        IEnumerable<ImageData> GetImages();
    }
}
