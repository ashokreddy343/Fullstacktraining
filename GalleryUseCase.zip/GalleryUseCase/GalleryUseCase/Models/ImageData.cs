﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GalleryUseCase.Models
{
    public class ImageData
    {
        public string Id { get; set; }
        public string ImageUrl { get; set; }
        public string Caption { get; set; }

        public string Description { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime PostedDate { get; set; }

        public string PosetedBy { get; set; }
    }
}
