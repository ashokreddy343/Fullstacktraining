﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GalleryUseCase.Models;
using GalleryUseCase.Services;
using Microsoft.AspNetCore.Mvc;

namespace GalleryUseCase.Controllers
{
    public class GalleryController : Controller
    {
        private IGalleryService galleryService;
        public GalleryController(IGalleryService galleryService)
        {
            this.galleryService = galleryService;
        }
        [HttpGet("",Name = "ListImage")]
        public IActionResult Index()
        {
            var model = galleryService.GetImages();
            return View(model);
        }

        [HttpGet("new",Name = "AddImage")]
        public IActionResult AddImage()
        {
            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost("new", Name = "AddImage")]
        public IActionResult AddImage(ImageData imageData)
        {
            if (ModelState.IsValid)
            {
                this.galleryService.AddImageData(imageData);
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("", "Invalid blog data");
            }
            return View();
        }
    }
}