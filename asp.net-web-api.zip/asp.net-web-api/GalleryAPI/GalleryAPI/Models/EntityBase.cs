﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GalleryAPI.Models
{
    public class EntityBase
    {
        public virtual int Id { set; get; }
    }
}
