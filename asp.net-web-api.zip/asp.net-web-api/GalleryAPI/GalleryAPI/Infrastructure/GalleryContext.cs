﻿using GalleryAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GalleryAPI.Infrastructure
{
    public class GalleryContext:DbContext
    {
        public GalleryContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<ImageData> Images { get; set; }
    }
}
