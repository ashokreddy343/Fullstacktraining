import React from "react";

class Registration extends React.Component {
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-6 col-md-offset-3">
            <div className="panel panel-login">
              <div className="panel-heading">
                <div className="row">
                  <div className="col-lg-7">
                    <h1>Registration</h1>
                  </div>
                </div>
                <hr />
              </div>
              <div className="panel-body">
                <div className="row">
                  <div className="col-lg-12">
                    <div className="form-group">
                      <input
                        type="text"
                        name="firstName"
                        id="firstName"
                        className="form-control"
                        placeholder="enter first Name"
                      />
                    </div>
                    <div className="form-group">
                      <input
                        type="text"
                        name="lastName"
                        id="lastName"
                        className="form-control"
                        placeholder="enter last Name"
                      />
                    </div>
                    <div className="form-group">
                      <input
                        type="text"
                        name="email"
                        id="email"
                        className="form-control"
                        placeholder="enter email"
                      />
                    </div>
                    <div className="form-group">
                      <input
                        type="password"
                        name="password"
                        id="password"
                        className="form-control"
                        placeholder=" enter Password"
                      />
                    </div>
                    <div class="dropdown form-group">
                      <button
                        class="btn btn-primary dropdown-toggle"
                        type="button"
                        data-toggle="dropdown"
                      >
                        Please select Role
                        <span class="caret" />
                      </button>
                      <ul class="dropdown-menu">
                        <li>
                          <a href="#">Admin</a>
                        </li>
                        <li>
                          <a href="#">Manager</a>
                        </li>
                        <li>
                          <a href="#">Employee</a>
                        </li>
                      </ul>
                    </div>

                    <div className="form-group">
                      <div className="row">
                        <div className="col-sm-6 col-sm-offset-3">
                          <button type="button" className="btn btn-primary">
                            Register
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Registration;
