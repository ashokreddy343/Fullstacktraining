import React from "react";
import DefaultCustomInsertModalHeaderTable from "./DefaultCustomInsertModalHeaderTable";

class Booking extends React.Component {
  render() {
    return (
      <div>
        <DefaultCustomInsertModalHeaderTable />
      </div>
    );
  }
}

export default Booking;
