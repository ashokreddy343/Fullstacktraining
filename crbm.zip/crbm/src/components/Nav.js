import React from "react";
import { Link, NavLink } from "react-router-dom";

class Nav extends React.Component {
  render() {
    return (
      <div>
        <nav className="navbar navbar-default">
          <div className="container-fluid">
            <div className="navbar-header">
              <NavLink
                activeClassName="activeLink"
                className="navbar-brand"
                to=""
              >
                Conference Room Booking
              </NavLink>
            </div>
            <ul className="nav navbar-nav">
              <li>
                <NavLink activeClassName="active" to="./dashboard">
                  Dashboard
                </NavLink>
              </li>
              <li>
                <Link activeClassName="active" to="./rooms">
                  Rooms
                </Link>
              </li>
              <li>
                <Link to="./booking">Booking</Link>
              </li>
            </ul>
            <ul className="nav navbar-nav navbar-right">
              <li>
                <Link to="./registration">
                  <span className="glyphicon glyphicon-user" /> Registration
                </Link>
              </li>
              <li>
                <Link to="./login">
                  <span className="glyphicon glyphicon-log-in" /> Login
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    );
  }
}

export default Nav;
