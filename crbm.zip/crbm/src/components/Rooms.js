import React from "react";
import RoomsStore from "./RoomsStore";

class Rooms extends React.Component {
  render() {
    return (
      <div>
        <div className="container">
          <RoomsStore />
        </div>
      </div>
    );
  }
}

export default Rooms;
