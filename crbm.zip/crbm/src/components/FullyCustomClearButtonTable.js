import React from "react";
import { BootstrapTable, TableHeaderColumn } from "react-bootstrap-table";

class FullyCustomClearButtonTable extends React.Component {
  createCustomClearButton = onClick => {
    return (
      <button className="btn btn-warning" onClick={onClick}>
        Clean
      </button>
    );
  };

  render() {
    const options = {
      clearSearch: true,
      clearSearchBtn: this.createCustomClearButton
    };
    let listOfRooms = [
      {
        id: 1,
        name: "Room-1"
      },
      {
        id: 2,
        name: "Room-2"
      },
      {
        id: 3,
        name: "Room-1"
      }
    ];
    return (
      <BootstrapTable data={listOfRooms} options={options} search>
        <TableHeaderColumn dataField="id" isKey={true}>
          Product ID
        </TableHeaderColumn>
        <TableHeaderColumn dataField="name">Product Name</TableHeaderColumn>
        <TableHeaderColumn dataField="price">Product Price</TableHeaderColumn>
        <TableHeaderColumn dataField="action">Edit</TableHeaderColumn>
      </BootstrapTable>
    );
  }
}

export default FullyCustomClearButtonTable;
