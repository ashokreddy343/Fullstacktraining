import React from "react";
import {
  BootstrapTable,
  TableHeaderColumn,
  InsertModalHeader
} from "react-bootstrap-table";

class DefaultCustomInsertModalHeaderTable extends React.Component {
  beforeClose(e) {
    alert(`[Custom Event]: Before modal close event triggered!`);
  }

  handleModalClose(closeModal) {
    // Custom your onCloseModal event here,
    // it's not necessary to implement this function if you have no any process before modal close
    console.log("This is my custom function for modal close event");
    closeModal();
  }

  createCustomModalHeader = (closeModal, save) => {
    return (
      <InsertModalHeader
        className="my-custom-class"
        title="This is my custom title"
        beforeClose={this.beforeClose}
        onModalClose={() => this.handleModalClose(closeModal)}
      />
      // hideClose={ true } to hide the close button
    );
  };

  render() {
    const options = {
      insertModalHeader: this.createCustomModalHeader
    };
    let bookings = [
      {
        id: 1,
        name: "test1"
      },
      {
        id: 2,
        name: "test2"
      },
      {
        id: 3,
        name: "test3"
      }
    ];
    return (
      <BootstrapTable data={bookings} options={options} insertRow>
        <TableHeaderColumn dataField="id" isKey={true}>
          Product ID
        </TableHeaderColumn>
        <TableHeaderColumn dataField="name">Product Name</TableHeaderColumn>
        <TableHeaderColumn dataField="price">Product Price</TableHeaderColumn>
      </BootstrapTable>
    );
  }
}

export default DefaultCustomInsertModalHeaderTable;
