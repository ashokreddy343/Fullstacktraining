import React from "react";
import { BootstrapTable, TableHeaderColumn } from "react-bootstrap-table";

class Rooms extends React.Component {
  render() {
    let products = [
      {
        id: 1,
        name: "Product1",
        price: 120
      },
      {
        id: 2,
        name: "Product2",
        price: 980
      },
      {
        id: 3,
        name: "Product3",
        price: 180
      },
      {
        id: 4,
        name: "Product4",
        price: 800
      }
    ];
    return (
      <div className="container">
        <BootstrapTable
          data={products}
          striped
          hover
          search={true}
          multiColumnSearch={true}
        >
          <TableHeaderColumn isKey dataField="id">
            Product ID
          </TableHeaderColumn>
          <TableHeaderColumn dataField="name" dataSort={true}>
            Product Name
          </TableHeaderColumn>
          <TableHeaderColumn dataField="price">Product Price</TableHeaderColumn>
        </BootstrapTable>
      </div>
    );
  }
}

export default Rooms;
